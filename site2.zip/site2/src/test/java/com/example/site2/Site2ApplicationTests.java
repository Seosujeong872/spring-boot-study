package com.example.site2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Site2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
